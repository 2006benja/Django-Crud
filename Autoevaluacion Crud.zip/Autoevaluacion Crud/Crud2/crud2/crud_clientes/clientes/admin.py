from django.contrib import admin
from .models import Clientes
# Register your models here.
admin.site.register(Clientes)
